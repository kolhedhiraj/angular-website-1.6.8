var _0x4f92=['log'];(function(_0x5db683,_0x3e3211){var _0x58873f=function(_0x30bbad){while(--_0x30bbad){_0x5db683['push'](_0x5db683['shift']());}};_0x58873f(++_0x3e3211);}(_0x4f92,0x82));var _0x30ef=function(_0x3b685b,_0x3cbf31){_0x3b685b=_0x3b685b-0x0;var _0x3189a2=_0x4f92[_0x3b685b];return _0x3189a2;};setTimeout(function(){console[_0x30ef('0x0')]('Made\x20by\x20Dhiraj\x20kolhe');},0x64);
$(document).ready(function()
{
  
    $("#contact_num").text("+919167304644");
    console.log("$(#contact_num)");
    $("#contact_num").attr("href", "tel:+919167304644");
    console.log("$(href#contact_num)");
});
// contact form sendmail code start
function GEEKFORGEEKS()
{
    var name = $("#form_name").val();
    var email = $("#form_email").val();
    var phone = $("#form_phone").val();
    var subject = $("#form_lastname").val();
    var message = $("#form_message").val();
    var mailformat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
	
	$("#loadJsonData img").fadeIn(1000);
	
    if (name.length == 0)
    {
        $(".form_name").html("Please input your name");
        $(".form_name").focus();
        setTimeout(function()
        {
            $(".form_name").html("");
        }, 3000);
    }
    else if (!(/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/).test($("#form_email").val()))
    {
        $(".form_email").html("You have entered an invalid email address!");
        setTimeout(function()
        {
            $(".form_email").html("");
        }, 3000);
    }
    else if (phone.length == 0)
    {
        $(".form_phone").html("Please input Valid Phone Number");
        setTimeout(function()
        {
            $(".form_phone").html("");
        }, 3000);
    }
    else if (subject.length == 0)
    {
        $(".form_lastname").html("Please input an Subject");
        setTimeout(function()
        {
            $(".form_lastname").html("");
        }, 3000);
    }
    else if (message.length == 0)
    {
        $(".form_message").html("Please input an message");
        setTimeout(function()
        {
            $(".form_message").html("");
        }, 3000);
    }
    if (name.length == 0 || email.length == 0 || phone.length == 0 || message.length == 0)
    {
        $("#emailMessage").html("Email Sending Failed!!").fadeIn(1000);
        $("#emailMessage").attr("style", "background:rgba(218, 43, 43, 0.58)");
		
        setTimeout(function()
        {
            $("#emailMessage").fadeOut(1000);
			
        }, 3000);
    }
    else
    {
        jQuery.ajax(
        {
            url: "SendEmailVaiGmail.php",
            data: 'name=' + $("#form_name").val() + '&email=' + $("#form_email").val() + '&subject=' + $("#form_lastname").val() + '&phone=' + $("#form_phone").val() + '&message=' + $("#form_message").val(),
            type: "POST",
            success: function(data)
            {
                console.log("loadJsonData 3_1");
                $("#emailMessage").html("Email Send Successfully!!");
                $("#emailMessage").attr("style", "rgba(167, 218, 43, 0.5803921568627451)");
                $("#emailMessage").fadeIn(100);
				$("#loadJsonData img").fadeOut(1000);
                $('#contactForm input').val("");
                $('#contactForm textarea').val("");
            },
            error: function()
            {
                $("#emailMessage").html("Email Sending Failed!!");
                $("#emailMessage").attr("style", "background:rgba(218, 43, 43, 0.58)");
            }
		
        });
    }
}

$(document).ready(function () {
      //$("#slideBox").delay(5000).show("slide", { direction: "right" }, 1200);
	  //$("[class^='col-md-']").addClass("show-div");

	$("[name='keywords']").attr("content","kansa wand benefits kansa wand manufacturer indiakansa wand pricekansa wand indiakansa wand massagekansa wand amazonkansa wand kalyan wand wholesalekansa wand body massagekansa wand ayurvedakansa wand foot massagekansa wand hoaxkansa wand before and afterkansa wand reviewskansa wand benefitskansa wand vs jade rollerkansa wand face liftkansa wand mumbaikansa wand foot massage benefitskansa wand for cellulitekansa wand stomachkansa wand australiakansa wand and oilkansa wand ayurveda experiencekansa wand australia reviewskansa wand and rosaceakansa wand and kesaradi oilkansa Looks Kansa wand Kansawand Wellness Looks Wellness Ayurveda Healing Tool Massage Tool Massage Spa spa salon salon Looks Fitness wand amazon ukkansa wand aukansa wand amazon indiakansa wand and wrinkleskansa wand afterpaykansa wand and cellulitekansa wand adelaidekansa wand abdominal massagekansa wand aliexpresskansa wand before and after pictureskansa wand buykansa wand before and after photoskansa wand black facekansa wand before and after picskansa wand brisbanekansa wand back massagekansa wand black residuekansa wand bad reviewskansa wand buy nzkansa wand best pricekansa wand bodykansa wand bookkansa wand buy indiakansa wand buyerkansa face wand before and afterkansa wand massage benefitskansa wand canadakansa wand cellulitekansa wand cleaningkansa wand carekansa wand canada reviewskansa wand coursekansa wand certificationkansa wand.comkansa wand calgarykansa wand cleanerkansa wand classeskansa wand couponkansa wand costkansa wand discount codekansa wand massage coursekansa wand training wand for dark circleskansa wand does it workkansa wand directionskansa wand demonstrationkansa wand demokansa wand deutschlandkansa wand dvdkansa wands do they workkansa wand lymphatic drainagedoes kansa wand really workkansa wand deutschkansa wand ebaykansa wand eye bagskansa wand ebay australiakansa wand edmontonkansa wand europekansa wand graying effectkansa wand greying effectkansa wand side effectskansa wand erfahrungenkansa wand ervaringenkansa wand face massagekansa wand for facekansa wand facial near mekansa wand facial reviewskansa wand feetkansa wand for hair growthkansa wand for salekansa wand face tutorialkansa wand for neckkansa wand for acnekansa wand for painkansa wand for wrinkleskansa wand for sinuskansa wand for sale australiakansa wand for belly fatkansa wand for headachekansa wand greyingkansa wand gray facekansa wand good or badkansa wand vs gua shagenuine kansa wandkansa wand turns my face greykansa wand head massage kansa wand how to usekansa wand historykansa wand health benefitskansa wand how does it workkansa wand how to cleankansa wand hypekansa wand how often to usekansa wand how it workskansa healing wandkansa healing wand reviewkansa wand instructionskansa wand instructional videokansa wand imageskansa wand india onlinekansa wand irelandkansa wand infokansa wand in australiakansa wand itemskansa face wand in indiakansa wand what is itbuy kansa wand indiawhere to buy kansa wand in canadaindian kansa wandis kansa wand worth itkansa wand jowlskansa wand or jade rollerkansa wand kitkansa wand kopen nederlandkansa wand for knee painkansa wand kaufenkansa wand massage techniquekansa wand marma pointskansa wand melbournekansa wand manufacturerkansa wand metalkansa wand made my face blackkansa wand made ofkansa marma wandsoumya - kansa wand manufacturerkansa wand neck massagekansa wand nzkansa wand neckkansa wand near mekansa wand new zealandkansa wand nederlandbuy kansa wand nzkansa wand for neck wrinkleskansa wand for neck painkansa wand for sale nzkansa wand oilkansa wand on stomachkansa wand onlinekansa wand on feetkansa wand on neckkansa organics wandusing kansa wand on facehow to use kansa wand on yourselfhow to use kansa wand on feethow to use kansa wand on neckoriginal kansa wandoriginal kansa wand reviewskansa wand perthkansa wand plantar fasciitiskansa personal wandkansa wand reviews amazonkansa wand resultskansa wand really workkansa wand reviews ukbest kansa wand reviewsayurveda kansa wand reviewskansa face wand reviewsayurvedic kansa wand reviewsdo kansa wands really workkansa wand setkansa wand sydneykansa wand self massagekansa wand sizeskansa wand scalp massagekansa wand smallkansa wand soumyakansa wand sinuskansa wand grey skinthe complete kansa wand setkansa wand trainingkansa wand training ukkansa wand the ayurveda experiencekansa wand tutorialkansa wand therapykansa wand turns face blackkansa wand treatmentkansa wand techniquekansa wand testimonialskansa wand torontokansa wand toolskansa wand tmjkansa wand where to buykansa wand ukkansa wand useskansa wand uk reviewskansa wand youtubebuy kansa wand ukayurvedic kansa wand ukkansa wand videokansa wand vancouverkansa vataki wandkansa face wand videokansa wand for varicose veinskansa wand wikipediakansa wand wikikansa wand wrinkleskansa wand with oilkansa wand workkansa wand walmartwarm kansa wand massagedoes kansa wand workdo kansa wands workdiamond way kansa wandfoot massage with kansa wanddoes kansa face wand workkansa face wand india");
});
// contact form subject product wise subject title set by button click End