google.maps.__gjsload__('overlay', function(_) {
    var Kw = _.oa("g"),
        Lw = _.n(),
        Mw = function(a) {
            a.bg = a.bg || new Lw;
            return a.bg
        },
        Nw = function(a) {
            this.aa = new _.sh(function() {
                var b = a.bg;
                if (a.getPanes()) {
                    if (a.getProjection()) {
                        if (!b.g && a.onAdd) a.onAdd();
                        b.g = !0;
                        a.draw()
                    }
                } else {
                    if (b.g)
                        if (a.onRemove) a.onRemove();
                        else a.remove();
                    b.g = !1
                }
            }, 0)
        },
        Ow = function(a, b) {
            function c() {
                return _.th(e.aa)
            }
            var d = Mw(a),
                e = d.He;
            e || (e = d.He = new Nw(a));
            _.B(d.$ || [], _.O.removeListener);
            var f = d.ha = d.ha || new _.Nn,
                g = b.__gm;
            f.bindTo("zoom", g);
            f.bindTo("offset", g);
            f.bindTo("center", g, "projectionCenterQ");
            f.bindTo("projection", b);
            f.bindTo("projectionTopLeft", g);
            f = d.Wh = d.Wh || new Kw(f);
            f.bindTo("zoom", g);
            f.bindTo("offset", g);
            f.bindTo("projection", b);
            f.bindTo("projectionTopLeft", g);
            a.bindTo("projection", f, "outProjection");
            a.bindTo("panes", g);
            d.$ = [_.O.addListener(a, "panes_changed", c), _.O.addListener(g, "zoom_changed", c), _.O.addListener(g, "offset_changed", c), _.O.addListener(b, "projection_changed", c), _.O.addListener(g, "projectioncenterq_changed", c)];
            c();
            b instanceof _.ef && (_.Si(b, "Ox"), _.lo("Ox", "-p", a))
        },
        Rw = function(a) {
            if (a) {
                var b = a.getMap(),
                    c = a.__gmop;
                if (c) {
                    if (c.map == b) return;
                    a.__gmop = null;
                    c.jg()
                }
                if (b && b instanceof _.ef) {
                    var d = b.__gm;
                    d.overlayLayer ? a.__gmop = new Pw(b, a, d.overlayLayer) : d.g.then(function(e) {
                        e = e.wa;
                        var f = new Qw(b, e);
                        e.ua(f);
                        d.overlayLayer = f;
                        Rw(a)
                    })
                }
            }
        },
        Pw = function(a, b, c) {
            this.map = a;
            this.ta = b;
            this.Ql = c;
            this.ue = !1;
            _.Si(this.map, "Ox");
            _.lo("Ox", "-p", this.ta);
            c.h.push(this);
            c.g && Sw(this, c.g);
            c.i.Sf()
        },
        Sw = function(a, b) {
            a.ta.get("projection") != b && (a.ta.bindTo("panes", a.map.__gm), a.ta.set("projection",
                b))
        },
        Qw = function(a, b) {
            this.j = a;
            this.i = b;
            this.g = null;
            this.h = []
        };
    _.A(Kw, _.P);
    Kw.prototype.changed = function(a) {
        "outProjection" != a && (a = !!(this.get("offset") && this.get("projectionTopLeft") && this.get("projection") && _.xd(this.get("zoom"))), a == !this.get("outProjection") && this.set("outProjection", a ? this.g : null))
    };
    _.A(Nw, _.P);
    Pw.prototype.draw = function() {
        this.ue || (this.ue = !0, this.ta.onAdd && this.ta.onAdd());
        this.ta.draw && this.ta.draw()
    };
    Pw.prototype.jg = function() {
        _.mo("Ox", "-p", this.ta);
        this.ta.unbindAll();
        this.ta.set("panes", null);
        this.ta.set("projection", null);
        _.jb(this.Ql.h, this);
        this.ue && (this.ue = !1, this.ta.onRemove ? this.ta.onRemove() : this.ta.remove())
    };
    Qw.prototype.dispose = _.n();
    Qw.prototype.Ta = function(a, b, c, d, e, f) {
        var g = this.g = this.g || new _.Go(this.j, this.i, _.n());
        g.Ta(a, b, c, d, e, f);
        a = _.Ca(this.h);
        for (b = a.next(); !b.done; b = a.next()) b = b.value, Sw(b, g), b.draw()
    };
    _.zf("overlay", {
        Kg: function(a) {
            if (a) {
                var b = a.getMap();
                if (b && b instanceof _.ef || a.__gmop) Rw(a);
                else {
                    b = a.getMap();
                    var c = Mw(a),
                        d = c.il;
                    c.il = b;
                    d && (c = Mw(a), (d = c.ha) && d.unbindAll(), (d = c.Wh) && d.unbindAll(), a.unbindAll(), a.set("panes", null), a.set("projection", null), _.B(c.$, _.O.removeListener), c.$ = null, c.He && (c.He.aa.Ra(), c.He = null), _.mo("Ox", "-p", a));
                    b && Ow(a, b)
                }
            }
        },
        preventMapHitsFrom: function(a) {
            _.vp(a, {
                onClick: function(b) {
                    return _.Oo(b.event)
                },
                Ma: function(b) {
                    return _.Lo(b)
                },
                sc: function(b) {
                    return _.Mo(b)
                },
                ab: function(b) {
                    return _.Mo(b)
                },
                Qa: function(b) {
                    return _.No(b)
                }
            }).Nc(!0)
        },
        preventMapHitsAndGesturesFrom: function(a) {
            a.addEventListener("click", _.ve);
            a.addEventListener("contextmenu", _.ve);
            a.addEventListener("dblclick", _.ve);
            a.addEventListener("mousedown", _.ve);
            a.addEventListener("mousemove", _.ve);
            a.addEventListener("MSPointerDown", _.ve);
            a.addEventListener("pointerdown", _.ve);
            a.addEventListener("touchstart", _.ve);
            a.addEventListener("wheel", _.ve)
        }
    });
});