//do not deletethis code ↓

(function ($) {
  "use strict";

  $.fn.placeholderTypewriter = function (options) {

    // Plugin Settings
    var settings = $.extend({
      delay: 90,
      pause: 6000,
      text: []
    }, options);

    // Type given string in placeholder
    function typeString($target, index, cursorPosition, callback) {

      // Get text
      var text = settings.text[index];

      // Get placeholder, type next character
      var placeholder = $target.attr('placeholder');
      $target.attr('placeholder', placeholder + text[cursorPosition]);

      // Type next character
      if (cursorPosition < text.length - 1) {
        setTimeout(function () {
          typeString($target, index, cursorPosition + 1, callback);
        }, settings.delay);
        return true;
      }

      // Callback if animation is finished
      callback();
    }

    // Delete string in placeholder
    function deleteString($target, callback) {

      // Get placeholder
      var placeholder = $target.attr('placeholder');
      var length = placeholder.length;

      // Delete last character
      $target.attr('placeholder', placeholder.substr(0, length - 1));

      // Delete next character
      if (length > 1) {
        setTimeout(function () {
          deleteString($target, callback)
        }, settings.delay);
        return true;
      }

      // Callback if animation is finished
      callback();
    }

    // Loop typing animation
    function loopTyping($target, index) {

      // Clear Placeholder
      $target.attr('placeholder', '');

      // Type string
      typeString($target, index, 0, function () {

        // Pause before deleting string
        setTimeout(function () {

          // Delete string
          deleteString($target, function () {
            // Start loop over
            loopTyping($target, (index + 1) % settings.text.length)
          })

        }, settings.pause);
      })

    }

    // Run placeholderTypewriter on every given field
    return this.each(function () {

      loopTyping($(this), 0);
    });

  };

}(jQuery));

(function($) {
    "use strict";
	window.onload = function(){
		 if ($('#preloader').length) {
            $('#preloader').delay(100).fadeOut('slow', function() {
                $(this).remove();
            });
        }
	$(".single-well .col-md-12 col-sm-12 col-xs-12").addClass("wow fadeInUp");
	$(".mobile-menu").on('click',function(){
		$(".navbar-right").toggleClass("showmenu");
	});
	
	}
$(document).click(function(e) {
    if ($(e.target).closest("#list-group").attr("id") != "list-group"){
       $("#list-group").hide();
	   console.log("dipslay:none");
    }
});
    $(window).scroll(function() {
        if ($(this).scrollTop() > 100) {
            $('.back-to-top').fadeIn('slow');
        } else {
            $('.back-to-top').fadeOut('slow');
        }
    });
    $('.back-to-top').click(function() {
        $('html, body').animate({
            scrollTop: 0
        }, 1500, 'easeInOutExpo');
        return false;
    });
    new WOW().init();
    $(window).scroll(function() {
        if ($(this).scrollTop() > 100) {
            $('#header').addClass('header-scrolled');
        } else {
            $('#header').removeClass('header-scrolled');
        }
    });
    if ($(window).scrollTop() > 100) {
        $('#header').addClass('header-scrolled');
    }
    $('.main-nav a, .mobile-nav a, .scrollto').on('click', function() {
        if (location.pathname.replace(/^\//, '') == this.pathname.replace(/^\//, '') && location.hostname == this.hostname) {
            var target = $(this.hash);
            if (target.length) {
                var top_space = 0;
                if ($('#header').length) {
                    top_space = $('#header').outerHeight();
                    if (!$('#header').hasClass('header-scrolled')) {
                        top_space = top_space - 20;
                    }
                }
                $('html, body').animate({
                    scrollTop: target.offset().top - top_space
                }, 1500, 'easeInOutExpo');
                if ($(this).parents('.main-nav, .mobile-nav').length) {
                    $('.main-nav .active, .mobile-nav .active').removeClass('active');
                    $(this).closest('li').addClass('active');
                }
                if ($('body').hasClass('mobile-nav-active')) {
                    $('body').removeClass('mobile-nav-active');
                    $('.mobile-nav-toggle i').toggleClass('fa-times fa-bars');
                    $('.mobile-nav-overly').fadeOut();
                }
                return false;
            }
        }
    });
    var nav_sections = $('section');
    var main_nav = $('.main-nav, .mobile-nav');
    var main_nav_height = $('#header').outerHeight();
    $(window).on('scroll', function() {
        var cur_pos = $(this).scrollTop();
        nav_sections.each(function() {
            var top = $(this).offset().top - main_nav_height,
                bottom = top + $(this).outerHeight();
            if (cur_pos >= top && cur_pos <= bottom) {
                main_nav.find('li').removeClass('active');
                main_nav.find('a[href="#' + $(this).attr('id') + '"]').parent('li').addClass('active');
            }
        });
    });
    $('[data-toggle="counter-up"]').counterUp({
        delay: 10,
        time: 1000
    });
    $(window).on('load', function() {
        var portfolioIsotope = $('.portfolio-container').isotope({
            itemSelector: '.portfolio-item'
        });
        $('#portfolio-flters li').on('click', function() {
            $("#portfolio-flters li").removeClass('filter-active');
            $(this).addClass('filter-active');
            portfolioIsotope.isotope({
                filter: $(this).data('filter')
            });
        });
    });
    $(".testimonials-carousel").owlCarousel({
        autoplay: true,
        dots: true,
        loop: true,
        items: 1
    });
})(jQuery);
/**
 * Main AngularJS Web Application
 */
var app = angular.module('eezzzee', ['ngRoute']);
 document.body.style.display = "block";
/**
 * Configure the Routes
 */
app.config(['$routeProvider', function ($routeProvider) {
  $routeProvider
    // Home
    .when("/", {templateUrl: "partials/home.html", controller: "PageCtrl"})
    // Pages
	.when("/search", {templateUrl: "partials/home.html", controller: "PageCtrl"})
    .when("/about", {templateUrl: "partials/about.html", controller: "PageCtrl"})
    .when("/faq", {templateUrl: "partials/faq.html", controller: "PageCtrl"})
	.when("/news", {templateUrl: "partials/news.html", controller: "PageCtrl"})
    .when("/pricing", {templateUrl: "partials/pricing.html", controller: "PageCtrl"})
    .when("/services", {templateUrl: "partials/services.html", controller: "PageCtrl"})
	.when("/doctor", {templateUrl: "partials/doctor.html", controller: "PageCtrl"})
	.when("/hotels", {templateUrl: "partials/hotels.html", controller: "PageCtrl"})
    .when("/contact", {templateUrl: "partials/contact.html", controller: "PageCtrl"})
	.when("/entertainment", {templateUrl: "partials/entertainment.html", controller: "PageCtrl"})
	.when("/gym", {templateUrl: "partials/gym.html", controller: "PageCtrl"})
	.when("/healthbeauty", {templateUrl: "partials/healthbeauty.html", controller: "PageCtrl"})
	.when("/restaurent", {templateUrl: "partials/restaurent.html", controller: "PageCtrl"})
	.when("/automobile", {templateUrl: "partials/automobile.html", controller: "PageCtrl"})
	.when("/educational", {templateUrl: "partials/educational.html", controller: "PageCtrl"})
	.when("/termsservice", {templateUrl: "partials/home.html", controller: "PageCtrl"})
	.when("/privacypolicy", {templateUrl: "partials/home.html", controller: "PageCtrl"})
	.when("/cbusiness", {templateUrl: "partials/home.html", controller: "PageCtrl"})
	.when("/msupport", {templateUrl: "partials/home.html", controller: "PageCtrl"})
	.when("/404", {templateUrl: "partials/404.html", controller: "PageCtrl"})
    // else 404
    .otherwise("/404", {templateUrl: "partials/404.html", controller: "PageCtrl"});
	
}]);
/**
 * Controls the Blog
 */
app.controller('BlogCtrl', function (/* $scope, $location, $http */) {
  console.log("Blog Controller reporting for duty.");
});
/**
 * Controls all other Pages
 */
app.controller('PageCtrl', function ($scope,$timeout,$interval /*, $location, $http */) {
  console.log("Page Controller reporting for duty.");

$scope.isActive = function (viewLocation) {
     var active = (viewLocation === $location.path());
     return active;
};
$timeout( function(){
    typescript();
	}, 100 );

$scope.AppendHtml = function() {
     var myEl = angular.element( document.querySelector("#main"));
     myEl.prepend("<div class='mc-sub-header-wrap wow fadeInDown'><div class='mc-sub-header'><a href='#' class='header-links header-btn-products header-btn-general _prod-id'><span>Merchant Tools</span></a><a href='javascript:void(0)' class='_login-overlay login-link header-links'><span>Log in</span></a><a href='#' class='header-links join-now'><span>Sign up</span></a></div></div>");     
    }
	
  // Activates the Carousel
  //$('.carousel').carousel({
  //  interval: 5000
  //});

  // Activates Tooltips for Social Links
  //$('.tooltip-social').tooltip({
  //  selector: "a[data-toggle=tooltip]"
  //})
});
app.directive('activeLink', function () {
    return {
        link: function (scope, element, attrs) {
            element.find('.nav a').on('click', function () {
                angular.element(this)
                    .parent().siblings('.active')
                    .removeClass('active');
                angular.element(this)
                    .parent()
                    .addClass('active');
            });
        }
    };
});
function typescript() {
}
app.controller('myCtrl',function($scope,$http){
		$scope.countryList = ["Afghanistan","Albania","Algeria","Andorra","Angola","Anguilla","Antigua & Barbuda","Argentina","Armenia","Aruba","Australia","Austria","Azerbaijan","Bahamas","Bahrain","Bangladesh","Barbados","Belarus","Belgium","Belize","Benin","Bermuda","Bhutan","Bolivia","Bosnia & Herzegovina","Botswana","Brazil","British Virgin Islands","Brunei","Bulgaria","Burkina Faso","Burundi","Cambodia","Cameroon","Cape Verde","Cayman Islands","Chad","Chile","China","Colombia","Congo","Cook Islands","Costa Rica","Cote D Ivoire","Croatia","Cruise Ship","Cuba","Cyprus","Czech Republic","Denmark","Djibouti","Dominica","Dominican Republic","Ecuador","Egypt","El Salvador","Equatorial Guinea","Estonia","Ethiopia","Falkland Islands","Faroe Islands","Fiji","Finland","France","French Polynesia","French West Indies","Gabon","Gambia","Georgia","Germany","Ghana","Gibraltar","Greece","Greenland","Grenada","Guam","Guatemala","Guernsey","Guinea","Guinea Bissau","Guyana","Haiti","Honduras","Hong Kong","Hungary","Iceland","India","Indonesia","Iran","Iraq","Ireland","Isle of Man","Israel","Italy","Jamaica","Japan","Jersey","Jordan","Kazakhstan","Kenya","Kuwait","Kyrgyz Republic","Laos","Latvia","Lebanon","Lesotho","Liberia","Libya","Liechtenstein","Lithuania","Luxembourg","Macau","Macedonia","Madagascar","Malawi","Malaysia","Maldives","Mali","Malta","Mauritania","Mauritius","Mexico","Moldova","Monaco","Mongolia","Montenegro","Montserrat","Morocco","Mozambique","Namibia","Nepal","Netherlands","Netherlands Antilles","New Caledonia","New Zealand","Nicaragua","Niger","Nigeria","Norway","Oman","Pakistan","Palestine","Panama","Papua New Guinea","Paraguay","Peru","Philippines","Poland","Portugal","Puerto Rico","Qatar","Reunion","Romania","Russia","Rwanda","Saint Pierre & Miquelon","Samoa","San Marino","Satellite","Saudi Arabia","Senegal","Serbia","Seychelles","Sierra Leone","Singapore","Slovakia","Slovenia","South Africa","South Korea","Spain","Sri Lanka","St Kitts & Nevis","St Lucia","St Vincent","St. Lucia","Sudan","Suriname","Swaziland","Sweden","Switzerland","Syria","Taiwan","Tajikistan","Tanzania","Thailand","Timor L'Este","Togo","Tonga","Trinidad & Tobago","Tunisia","Turkey","Turkmenistan","Turks & Caicos","Uganda","Ukraine","United Arab Emirates","United Kingdom","Uruguay","Uzbekistan","Venezuela","Vietnam","Virgin Islands (US)","Yemen","Zambia","Zimbabwe"];
		
		$scope.complete=function(string){
			console.log(string);
			var output=[];
			var listgroup = $("#list-group");
			angular.forEach($scope.countryList,function(country){
				if(country.toLowerCase().indexOf(string.toLowerCase())>=0){
					output.push(country);
					listgroup.show();
				}
			});
			$scope.filterCountry=output;
		}
		$scope.fillTextbox=function(string){
			$scope.country=string;
			$scope.filterCountry=null;
		}
	});
app.controller('selectCategoryCtrl', function ($scope) {
	$scope.arrlist = [{
		"userid": 1,
		"name": "Autos"
	}, {
		"userid": 2,
		"name": "Home & Garden"
	}, {
		"userid": 3,
		"name": "Real Estate"
	}, {
		"userid": 4,
		"name": "Health & Beauty"
	}, {
		"userid": 5,
		"name": "Legal & Financial"
	}, {
		"userid": 6,
		"name": "Food & Dining"
	}, {
		"userid": 7,
		"name": "Business To Business"
	}, {
		"userid": 8,
		"name": "Community"
	}, {
		"userid": 9,
		"name": "Education"
	}, {
		"userid": 10,
		"name": "Electronics"
	}, {
		"userid": 11,
		"name": "Entertainment & Arts"
	}, {
		"userid": 12,
		"name": "Professional Services"
	}, {
		"userid": 13,
		"name": "Recreation"
	}, {
		"userid": 14,
		"name": "Retail Shopping"
	}];
});
app.controller('selectStateCtrl', function ($scope) {
	$scope.arrlist = [{
		"stateid": 1,
		"name": "Jammu and Kashmir"
	}, {
		"stateid": 2,
		"name": "Punjab"
	}, {
		"stateid": 3,
		"name": "Himachal Pradesh"
	}, {
		"stateid": 4,
		"name": "Haryana"
	}, {
		"stateid": 5,
		"name": "Delhi"
	}, {
		"stateid": 6,
		"name": "Rajasthan"
	}, {
		"stateid": 7,
		"name": "Uttar Pradesh"
	}, {
		"stateid": 8,
		"name": "Uttarakhand"
	}, {
		"stateid": 9,
		"name": "Madhya Pradesh"
	}, {
		"stateid": 10,
		"name": "Chattisgarh"
	}, {
		"stateid": 11,
		"name": "Gujarat"
	}, {
		"stateid": 12,
		"name": "Maharashtra"
	}, {
		"stateid": 13,
		"name": "Karnataka"
	}, {
		"stateid": 14,
		"name": "Goa"
	}, {
		"stateid": 15,
		"name": "Kerala"
	}, {
		"stateid": 16,
		"name": "Tamil nadu"
	}, {
		"stateid": 17,
		"name": "Andhra Pradesh"
	}, {
		"stateid": 18,
		"name": "Telangana"
	}, {
		"stateid": 19,
		"name": "Orissa"
	}, {
		"stateid": 20,
		"name": "Bihar"
	}, {
		"stateid": 21,
		"name": "Jharkhand"
	}, {
		"stateid": 22,
		"name": "West Bengal"
	}, {
		"stateid": 23,
		"name": "Assam"
	}, {
		"stateid": 24,
		"name": "Arunach Pradesh"
	}, {
		"stateid": 25,
		"name": "Sikkim"
	}, {
		"stateid": 26,
		"name": "Meghalaya"
	}, {
		"stateid": 27,
		"name": "Mizoram"
	}, {
		"stateid": 28,
		"name": "Nagaland"
	}, {
		"stateid": 29,
		"name": "Tripura"
	}];
});
app.controller('selectCityCtrl', function ($scope) {
	$scope.arrlist = [{
		"cityid": 1,
		"name": "AGARTALA"
	}, {
		"cityid": 2,
		"name": "AGRA"
	}, {
		"cityid": 3,
		"name": "AHMEDABAD"
	}, {
		"cityid": 4,
		"name": "AIZWAL"
	}, {
		"cityid": 5,
		"name": "AJMER"
	}, {
		"cityid": 6,
		"name": "ALLAHABAD"
	}, {
		"cityid": 7,
		"name": "ALLEPPEY"
	}, {
		"cityid": 8,
		"name": "ALIBAUG"
	}, {
		"cityid": 9,
		"name": "ALMORA"
	}, {
		"cityid": 10,
		"name": "ALSISAR"
	}, {
		"cityid": 11,
		"name": "ALWAR"
	}, {
		"cityid": 12,
		"name": "AMBALA"
	}, {
		"cityid": 13,
		"name": "AMLA"
	}, {
		"cityid": 14,
		"name": "AMRITSAR"
	}, {
		"cityid": 15,
		"name": "ANAND"
	}, {
		"cityid": 16,
		"name": "ANKLESHWAR"
	}, {
		"cityid": 17,
		"name": "ASHTAMUDI"
	}, {
		"cityid": 18,
		"name": "AULI"
	}, {
		"cityid": 19,
		"name": "AURANGABAD"
	}, {
		"cityid": 20,
		"name": "BADDI"
	}, {
		"cityid": 21,
		"name": "BADRINATH"
	}, {
		"cityid": 22,
		"name": "BALASINOR"
	}, {
		"cityid": 23,
		"name": "BALRAMPUR"
	}, {
		"cityid": 24,
		"name": "BAMBORA"
	}, {
		"cityid": 25,
		"name": "BANDHAVGARH"
	}, {
		"cityid": 26,
		"name": "BANDIPUR"
	}, {
		"cityid": 27,
		"name": "BANGALORE"
	}, {
		"cityid": 28,
		"name": "BARBIL"
	}, {
		"cityid": 29,
		"name": "BAREILLY"
	}, {
		"cityid": 30,
		"name": "BEHROR"
	}, {
		"cityid": 31,
		"name": "BELGAUM"
	}, {
		"cityid": 32,
		"name": "BERHAMPUR"
	}, {
		"cityid": 33,
		"name": "BETALGHAT"
	}, {
		"cityid": 34,
		"name": "BHARATPUR"
	}, {
		"cityid": 35,
		"name": "BHANDARDARA"
	}, {
		"cityid": 36,
		"name": "BHARUCH"
	}, {
		"cityid": 37,
		"name": "BHAVANGADH"
	}, {
		"cityid": 38,
		"name": "BHAVNAGAR"
	}, {
		"cityid": 39,
		"name": "BHILAI"
	}, {
		"cityid": 40,
		"name": "BHIMTAL"
	}, {
		"cityid": 41,
		"name": "BHOPAL"
	}, {
		"cityid": 42,
		"name": "BHUBANESHWAR"
	}, {"cityid": 43,
	"name": "BHUJ"
	}, {
		"cityid": 44,
		"name": "BIKANER"
	}, {
		"cityid": 45,
		"name": "BINSAR"
	}, {
		"cityid": 46,
		"name": "BODHGAYA"
	}, {
		"cityid": 47,
		"name": "BUNDI"
	}, {
		"cityid": 48,
		"name": "CALICUT"
	}, {
		"cityid": 49,
		"name": "CANANNORE"
	}, {
		"cityid": 50,
		"name": "CHAIL"
	}
, {"cityid": 51,"name": "CHAMBA"}
, {"cityid": 52,"name": "CHANDIGARH"}
, {"cityid": 53,"name": "CHENNAI"}
, {"cityid": 54,"name": "CHIKMAGALUR"}
, {"cityid": 55,"name": "CHIPLUN"}
, {"cityid": 56,"name": "CHITRAKOOT"}
, {"cityid": 57,"name": "CHITTORGARH"}
, {"cityid": 58,"name": "COIMBATORE"}
, {"cityid": 59,"name": "COONOOR"}
, {"cityid": 60,"name": "COORG"}
, {"cityid": 61,"name": "CORBETT NATIONAL PARK"}
, {"cityid": 62,"name": "CUTTACK"}
, {"cityid": 63,"name": "DABHOSA"}
, {"cityid": 64,"name": "DALHOUSIE"}
, {"cityid": 65,"name": "DAMAN"}
, {"cityid": 66,"name": "DANDELI"}
, {"cityid": 67,"name": "DAPOLI"}
, {"cityid": 68,"name": "DARJEELING"}
, {"cityid": 69,"name": "DAUSA"}
, {"cityid": 70,"name": "DEHRADUN"}
, {"cityid": 71,"name": "DHARAMSHALA"}
, {"cityid": 72,"name": "DIBRUGARH"}
, {"cityid": 73,"name": "DIGHA"}
, {"cityid": 74,"name": "DIU"}
, {"cityid": 75,"name": "DIVE AGAR"}
, {"cityid": 76,"name": "DOOARS"}
, {"cityid": 77,"name": "DURGAPUR"}
, {"cityid": 78,"name": "DURSHET"}
, {"cityid": 79,"name": "DWARKA"}
, {"cityid": 80,"name": "FARIDABAD"}
, {"cityid": 81,"name": "FIROZABAD"}
, {"cityid": 82,"name": "GANGOTRI"}
, {"cityid": 83,"name": "GANGTOK"}
, {"cityid": 84,"name": "GANAPATIPULE"}
, {"cityid": 85,"name": "GANDHIDHAM"}
, {"cityid": 86,"name": "GANDHINAGAR"}
, {"cityid": 87,"name": "GARHMUKTESHWAR"}
, {"cityid": 88,"name": "GARHWAL"}
, {"cityid": 89,"name": "GAYA"}
, {"cityid": 90,"name": "GHAZIABAD"}
, {"cityid": 91,"name": "GOA"}
, {"cityid": 92,"name": "GOKHARNA"}
, {"cityid": 93,"name": "GONDAL"}
, {"cityid": 94,"name": "GORAKHPUR"}
, {"cityid": 96,"name": "GREATER NOIDA"}
, {"cityid": 97,"name": "GULMARG"}
, {"cityid": 98,"name": "GURGAON"}
, {"cityid": 99,"name": "GURUVAYOOR"}
, {"cityid": 100,"name": "GUWAHATI"}
, {"cityid": 101,"name": "GWALIOR"}
, {"cityid": 102,"name": "HALEBID"}
, {"cityid": 103,"name": "HAMPI"}
, {"cityid": 104,"name": "HANSI"}
, {"cityid": 105,"name": "HARIDWAR"}
, {"cityid": 106,"name": "HASSAN"}
, {"cityid": 107,"name": "HOSPET"}
, {"cityid": 108,"name": "HOSUR"}
, {"cityid": 109,"name": "HUBLI"}
, {"cityid": 110,"name": "HYDERABAD"}
, {"cityid": 111,"name": "IDUKKI"}
, {"cityid": 112,"name": "IGATPURI"}
, {"cityid": 113,"name": "IMPHAL"}
, {"cityid": 114,"name": "INDORE"}
, {"cityid": 115,"name": "JABALPUR"}
, {"cityid": 116,"name": "JAIPUR"}
, {"cityid": 117,"name": "JAISALMER"}
, {"cityid": 118,"name": "JALANDHAR"}
, {"cityid": 119,"name": "JALGAON"}
, {"cityid": 120,"name": "JAMBUGODHA"}
, {"cityid": 121,"name": "JAMMU"}
, {"cityid": 122,"name": "JAMNAGAR"}
, {"cityid": 123,"name": "JAMSHEDPUR"}
, {"cityid": 124,"name": "JAWHAR"}
, {"cityid": 125,"name": "JHANSI"}
, {"cityid": 126,"name": "JODHPUR"}];
});