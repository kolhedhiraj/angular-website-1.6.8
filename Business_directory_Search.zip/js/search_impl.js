google.maps.__gjsload__('search_impl', function(_) {
    var G$ = function(a) {
            _.D(this, a, 4)
        },
        oha = function(a) {
            var b = _.Qh;
            H$ || (H$ = {
                D: "sssM",
                G: ["ss"]
            });
            return b.g(a.m, H$)
        },
        pha = function(a, b) {
            a.m[2] = b
        },
        I$ = function(a) {
            _.D(this, a, 3)
        },
        J$ = function() {
            var a = _.bj,
                b = _.ki;
            this.h = _.I;
            this.g = _.rl(_.Ep, a, _.vt + "/maps/api/js/LayersService.GetFeature", b)
        },
        K$ = _.n(),
        H$;
    _.A(G$, _.C);
    G$.prototype.getParameter = function(a) {
        return new _.DV(_.Ul(this, 3, a))
    };
    _.A(I$, _.C);
    I$.prototype.getStatus = function() {
        return _.$c(this, 0, -1)
    };
    I$.prototype.getLocation = function() {
        return new _.Um(this.m[1])
    };
    J$.prototype.load = function(a, b) {
        function c(g) {
            g = new I$(g);
            b(g)
        }
        var d = new G$;
        d.m[0] = a.Ea.split("|")[0];
        d.m[1] = a.g;
        pha(d, _.gd(_.hd(this.h)));
        for (var e in a.parameters) {
            var f = new _.DV(_.dd(d, 3));
            f.m[0] = e;
            f.m[1] = a.parameters[e]
        }
        a = oha(d);
        this.g(a, c, c);
        return a
    };
    J$.prototype.cancel = function() {
        throw Error("Not implemented");
    };
    var L$ = {
        nf: function(a) {
            if (_.Ch[15]) {
                var b = a.j,
                    c = a.j = a.getMap();
                b && L$.jg(a, b);
                c && L$.zj(a, c)
            }
        },
        zj: function(a, b) {
            var c = L$.Ae(a.get("layerId"), a.get("spotlightDescription"), a.get("paintExperimentIds"));
            a.g = c;
            a.i = a.get("renderOnBaseMap");
            a.i ? (a = b.__gm.h, a.set(_.om(a.get(), c))) : L$.wj(a, b, c);
            _.Si(b, "Lg")
        },
        wj: function(a, b, c) {
            var d = _.ZD(new J$);
            c.rh = (0, _.z)(d.load, d);
            c.clickable = 0 != a.get("clickable");
            _.TW.Jg(c, b);
            var e = [];
            e.push(_.O.addListener(c, "click", (0, _.z)(L$.xg, L$, a)));
            _.B(["mouseover", "mouseout", "mousemove"],
                function(f) {
                    e.push(_.O.addListener(c, f, (0, _.z)(L$.Rm, L$, a, f)))
                });
            e.push(_.O.addListener(a, "clickable_changed", function() {
                a.g.clickable = 0 != a.get("clickable")
            }));
            a.h = e
        },
        Ae: function(a, b, c) {
            var d = new _.Bs;
            a = a.split("|");
            d.Ea = a[0];
            for (var e = 1; e < a.length; ++e) {
                var f = a[e].split(":");
                d.parameters[f[0]] = f[1]
            }
            b && (d.Re = new _.Uq(b));
            c && (d.Th = c.slice(0));
            return d
        },
        xg: function(a, b, c, d, e) {
            var f = null;
            if (e && (f = {
                    status: e.getStatus()
                }, 0 == e.getStatus())) {
                f.location = _.Sl(e, 1) ? new _.N(_.F(e.getLocation(), 0), _.F(e.getLocation(),
                    1)) : null;
                f.fields = {};
                for (var g = 0, h = _.ed(e, 2); g < h; ++g) {
                    var k = new _.DV(_.Ul(e, 2, g));
                    f.fields[k.getKey()] = k.Ja()
                }
            }
            _.O.trigger(a, "click", b, c, d, f)
        },
        Rm: function(a, b, c, d, e, f, g) {
            var h = null;
            f && (h = {
                title: f[1].title,
                snippet: f[1].snippet
            });
            _.O.trigger(a, b, c, d, e, h, g)
        },
        jg: function(a, b) {
            a.g && (a.i ? (b = b.__gm.h, b.set(b.get().Wb(a.g))) : L$.bm(a, b))
        },
        bm: function(a, b) {
            a.g && _.TW.Zh(a.g, b) && (_.B(a.h || [], _.O.removeListener), a.h = null)
        }
    };
    K$.prototype.nf = L$.nf;
    _.zf("search_impl", new K$);
});