(function ($) {
    "use strict";

	jQuery(document).ready(function() {


		var loading;
		var results;
		var display;

		//////////////////////
		// Domain Checker 01 //
		//////////////////////
		jQuery(".domainForm").on("submit", function(e){
				e.preventDefault();
				var form = this;
                var btn_value = $('.domain-search-btn .button-value');
                var btn_loader = $('.domain-search-btn .button-loader');

				var formData = jQuery('.domainForm').data('form-options');

                if( jQuery('.domainForm').hasClass('inline-domain-form') ) {

                    var domainName = jQuery('#domain_name').val();

    				if( ! domainName ){
    					jQuery(".domain-search-result").show().html('<p class="domain-error">'+ formData.error_text +'</p>');
    					jQuery('.select-domain').hide().empty();
    					return false;
    				} else {
    					jQuery(".domain-search-result").hide().empty();
    				}

                } else {
                    var domainName = jQuery('#domain_name').val();
    				var domainTLD = jQuery('#domain_tld').val();


    				if( ! domainName || ! domainTLD ){
    					jQuery(".domain-search-result").show().html('<p class="domain-error">'+ formData.error_text +'</p>');
    					jQuery('.select-domain').hide().empty();
    					return false;
    				} else {
    					jQuery(".domain-search-result").hide().empty();
    				}

    				if ( domainTLD !== '' ) {
    					domainName = domainName + domainTLD;
    				}
                }


				jQuery('.btn-loader').show();

				jQuery(".domain-search-result").html('');
				jQuery('.select-domain').hide().empty();
                btn_value.hide();
                btn_loader.show();

				var data = {
		      		'action': 'wdc_display',
					'domain': domainName,
		      		'security' : slake_ajax.wdc_nonce
			    };

				jQuery.post(slake_ajax.ajaxurl, data, function(response) {

				jQuery('.btn-loader').hide();

				var x = JSON.parse(response);
					if(x.status == 1){

						display = x.text;

						console.log( display);

						var appendedForm = '';
							appendedForm += '<form class="add-to-bridge" method="post" action="'+ slake_ajax.whmcsBridgeUrl +'?ccce=cart&a=add&domain=register&query='+ x.domain_name +'&systpl=six">';
							appendedForm += '<input type="text" class="hide-it" name="domain" value="'+ x.domain +'">';
							appendedForm += '<input type="submit" value="Buy now"> </form>';

						jQuery('.domain-search-result').show().html(display + appendedForm);
                        btn_value.show();
                        btn_loader.hide();

					}else if(x.status == 0) {
						display = x.text;
						jQuery(".domain-search-result").show().html('<p class="domain-error">'+ display +'</p>');
                        btn_value.show();
                        btn_loader.hide();
					}else{
						display = formData.failed_error_text;
                        btn_value.show();
                        btn_loader.hide();
					}
				jQuery("div[id='results']",form).css('display','block');
				jQuery(".loader",form).hide();
				jQuery("div[id='results']",form).html(unescape(display));

			});
			return false;
		});


	});

}(jQuery));
