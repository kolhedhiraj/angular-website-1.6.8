;(function(){

 
	
	//var elem = document.createElement('div');
	//elem.setAttribute('data-pen-credit','');
	//document.body.appendChild(elem);

	function check() {

  if (
    !document.fullscreenElement &&
    !document.mozFullScreenElement &&
    !document.webkitFullscreenElement &&
    !document.msFullscreenElement
  ) {
    console.log('not fullscreen');
    document.getElementsByClassName("vcard")[0].style.display = "block";
  } else {
    console.log('fullscreen');
    document.getElementsByClassName("vcard")[0].style.display = "none";
  }
}
["", "webkit", "moz", "ms"].forEach(
    prefix => document.addEventListener(prefix+"fullscreenchange", check, false)
);
	
  var el = document.querySelector('[data-pen-credit]');

  if ( el ) {
 
    el.className += ' kf_credit';
    
    var hasText = el.innerHTML.length;
    el.insertAdjacentHTML('afterbegin', `
<div class="vcard" onclick="this.classList.add('expand')">
  <div class="from">
    <div class="from-contents">
      <div class="avatar me"></div>
      <div class="name">Benjamin Høegh</div>
    </div>
  </div>
  <div class="to">
    <div class="to-contents">
      <div class="top">
        <div class="avatar-large me"></div>
        <div class="name-large">Benjamin Høegh</div>
        <div class="x-touch" onclick="document.querySelector('.vcard').classList.remove('expand');event.stopPropagation();">
          <div class="x">
            <div class="line1"></div>
            <div class="line2"></div>
          </div>
        </div>
      </div>
      <div class="bottom">
        <div class="row">
          <svg class="twitter" viewBox="0 0 300 244.187">
            <path d="M94.719 243.187c112.46 0 173.956-93.168 173.956-173.956 0-2.647-.054-5.28-.173-7.903A124.323 124.323 0 0 0 299 29.668c-10.955 4.87-22.744 8.147-35.11 9.625 12.623-7.569 22.314-19.543 26.885-33.817a122.61 122.61 0 0 1-38.824 14.84C240.794 8.433 224.911 1 207.322 1c-33.763 0-61.144 27.38-61.144 61.132 0 4.798.537 9.465 1.586 13.94C96.948 73.517 51.89 49.188 21.738 12.194a60.978 60.978 0 0 0-8.278 30.73c0 21.212 10.793 39.938 27.207 50.893a60.69 60.69 0 0 1-27.69-7.647c-.01.257-.01.507-.01.781 0 29.61 21.076 54.332 49.052 59.934a61.22 61.22 0 0 1-16.122 2.152c-3.934 0-7.766-.387-11.49-1.103C42.19 172.227 64.76 189.904 91.52 190.4c-20.925 16.402-47.287 26.17-75.937 26.17-4.929 0-9.798-.28-14.584-.846 27.059 17.344 59.19 27.464 93.722 27.464" fill="#1da1f2"/>
          </svg>
          <div class="link"><a rel="noopener" target="_blank" href="https://twitter.com/benjamin_hoegh">@benjamin_hoegh</a></div>
        </div>
        <div class="row">
          <svg class="codepen" viewBox="0 0 100 100">
            <path d="M100 34.2c-.4-2.6-3.3-4-5.3-5.3-3.6-2.4-7.1-4.7-10.7-7.1-8.5-5.7-17.1-11.4-25.6-17.1-2-1.3-4-2.7-6-4-1.4-1-3.3-1-4.8 0-5.7 3.8-11.5 7.7-17.2 11.5L5.2 29C3 30.4.1 31.8 0 34.8c-.1 3.3 0 6.7 0 10v16c0 2.9-.6 6.3 2.1 8.1 6.4 4.4 12.9 8.6 19.4 12.9 8 5.3 16 10.7 24 16 2.2 1.5 4.4 3.1 7.1 1.3 2.3-1.5 4.5-3 6.8-4.5 8.9-5.9 17.8-11.9 26.7-17.8l9.9-6.6c.6-.4 1.3-.8 1.9-1.3 1.4-1 2-2.4 2-4.1V37.3c.1-1.1.2-2.1.1-3.1 0-.1 0 .2 0 0zM54.3 12.3L88 34.8 73 44.9 54.3 32.4V12.3zm-8.6 0v20L27.1 44.8 12 34.8l33.7-22.5zM8.6 42.8L19.3 50 8.6 57.2V42.8zm37.1 44.9L12 65.2l15-10.1 18.6 12.5v20.1zM50 60.2L34.8 50 50 39.8 65.2 50 50 60.2zm4.3 27.5v-20l18.6-12.5 15 10.1-33.6 22.4zm37.1-30.5L80.7 50l10.8-7.2-.1 14.4z"/>
          </svg>
          <div class="link"><a rel="noopener" target="_blank" href="https://codepen.io/benjaminhoegh">@benjaminhoegh</a></div>
        </div>
      </div>
    </div>
  </div>
</div>`);

    document.head.insertAdjacentHTML('beforeend',`<style>
.vcard {
  font-family: sans-serif;
  background: #fff;
  border-radius: 7px;
  height: 28px;
  overflow: hidden;
  position: fixed;
  bottom: 15px;
  right: 20px;
  width: 142px;
  box-shadow: 0 0 30px 0 rgba(150,150,150,0.5);
  -webkit-tap-highlight-color: transparent;
  transition: width 300ms cubic-bezier(0.4, 0, 0.2, 1), height 300ms cubic-bezier(0.4, 0, 0.2, 1), box-shadow 300ms cubic-bezier(0.4, 0, 0.2, 1), border-radius 300ms cubic-bezier(0.4, 0, 0.2, 1);
  z-index: 999999999999;
}
.vcard:not(.expand) {
  cursor: pointer;
}
.vcard:not(.expand):hover {
  background: #c2c0c2;
}
.vcard .from {
  position: absolute;
  transition: opacity 200ms 100ms cubic-bezier(0, 0, 0.2, 1);
}
.vcard .from-contents {
  display: flex;
  flex-direction: row;
  transform-origin: 0 0;
  transition: transform 300ms cubic-bezier(0.4, 0, 0.2, 1);
}
.vcard .me {
  background-image: url("https://s3-us-west-2.amazonaws.com/s.cdpn.io/951933/profile/profile-80.jpg?1543137230");
  background-size: cover;
}
.vcard .to {
  opacity: 0;
  position: absolute;
  transition: opacity 100ms cubic-bezier(0.4, 0, 1, 1);
}
.vcard .to-contents {
  transform: scale(0.55);
  transform-origin: 0 0;
  transition: transform 300ms cubic-bezier(0.4, 0, 0.2, 1);
}
.vcard .avatar {
  border-radius: 12px;
  height: 20px;
  left: 6px;
  position: relative;
  top: 4px;
  width: 20px;
}
.vcard .name {
  font-size: 14px;
  line-height: 28px;
  margin-left: 10px;
}
.vcard .top {
  background: #E45346;
  display: flex;
  flex-direction: row;
  height: 70px;
  transition: height 300ms cubic-bezier(0.4, 0, 0.2, 1);
  width: 300px;
}
.vcard .avatar-large {
  border-radius: 21px;
  height: 42px;
  margin-left: 12px;
  position: relative;
  top: 14px;
  width: 42px;
}
.vcard .name-large {
  color: #fff;
  font-size: 16px;
  line-height: 70px;
  margin-left: 20px;
}
.vcard .x-touch {
  align-items: center;
  align-self: center;
  cursor: pointer;
  display: flex;
  height: 50px;
  justify-content: center;
  margin-left: auto;
  width: 50px;
}
.vcard .x {
  background: #d74437;
  border-radius: 10px;
  height: 20px;
  position: relative;
  width: 20px;
}
.vcard .x-touch:hover .x {
  background: #ea7e74;
}
.vcard .line1 {
  background: #f6c8c4;
  height: 12px;
  position: absolute;
  transform: translateX(9px) translateY(4px) rotate(45deg);
  width: 2px;
}
.vcard .line2 {
  background: #f6c8c4;
  height: 12px;
  position: absolute;
  transform: translateX(9px) translateY(4px) rotate(-45deg);
  width: 2px;
}
.vcard .bottom {
  background: #fff;
  color: #444247;
  font-size: 14px;
  height: 200px;
  padding-top: 5px;
  width: 300px;
}
.vcard .row {
  align-items: center;
  display: flex;
  flex-direction: row;
  height: 60px;
}
.vcard .twitter {
  margin-left: 16px;
  height: 30px;
  position: relative;
  top: 0;
  width: 30px;
}
.vcard .codepen {
  height: 30px;
  margin-left: 16px;
  position: relative;
  width: 30px;
}
.vcard .link {
  margin-left: 16px;
}
.vcard .link a {
  color: #444247;
  text-decoration: none;
}
.vcard .link a:hover {
  color: #777579;
}
.vcard.expand {
  border-radius: 6px;
  box-shadow: 0 10px 20px rgba(0, 0, 0, 0.1), 0 6px 6px rgba(0, 0, 0, 0.16);
  height: 200px;
  width: 300px;
}
.vcard.expand .from {
  opacity: 0;
  transition: opacity 100ms cubic-bezier(0.4, 0, 1, 1);
}
.vcard.expand .from-contents {
  transform: scale(1.91);
}
.vcard.expand .to {
  opacity: 1;
  transition: opacity 200ms 100ms cubic-bezier(0, 0, 0.2, 1);
}
.vcard.expand .to-contents {
  transform: scale(1);
}
</style>`); 
  }

})();